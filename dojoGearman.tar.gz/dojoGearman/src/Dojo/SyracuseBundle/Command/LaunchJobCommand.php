<?php

namespace Dojo\SyracuseBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class DefineApiUserCommand
 * @package LaFourchette\ApiBundle\Command
 */
class LaunchJobCommand extends ContainerAwareCommand
{
    /**
     * Configure command
     */
    protected function configure()
    {
        $this
            ->setName('dojo:launchJob')
            ->setDescription('Launch a Syracuse Job')
            ->addArgument('number', InputArgument::REQUIRED, 'Number to use in the algo')
        ;
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|null|void
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $jobLauncherBusiness = $this->getContainer()->get('syracuse.business.job_launcher');

        $jobLauncherBusiness->launch($input->getArgument('number'));

        $output->writeLn('Job successfully launched.');
    }
}
