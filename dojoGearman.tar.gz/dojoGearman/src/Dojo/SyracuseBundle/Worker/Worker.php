<?php

namespace Dojo\SyracuseBundle\Worker;

use Mmoreram\GearmanBundle\Driver\Gearman;
use Dojo\SyracuseBundle\Business\SyracuseCalculator;
use Symfony\Component\HttpKernel\Log\LoggerInterface;

/**
 * @Gearman\Work(
 *     name = "DojoWorker",
 *     iterations = 2,
 *     description = "Dojo worker",
 *     defaultMethod = "doBackground",
 *     service="syracuse.worker"
 * )
 */
class Worker
{

    /**
     *
     * @var SyracuseCalculator
     */
    protected $syracuseCalculator;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @param SyracuseCalculator $syracuseCalculator
     * @param LoggerInterface $logger
     */
    public function __construct(SyracuseCalculator $syracuseCalculator, LoggerInterface $logger)
    {
        $this->syracuseCalculator = $syracuseCalculator;
        $this->logger = $logger;
    }

    /**
     * Customer export job
     *
     * @param \GearmanJob $job Object with job parameters
     *
     * @return boolean
     *
     * @Gearman\Job(
     *     iterations = 1,
     *     name = "computeSyracuse",
     *     defaultMethod = "doBackground",
     *     description = "run the syracuse algo"
     * )
     */
    public function compute(\GearmanJob $job)
    {
        $params = json_decode($job->workload(), true);

        $n = $params['number'];

        $this->logger->info('Computing ' . $n . ' for ' . $params['name'] . '.');

        //$this->logger->info('Result : ' . $result . '.');

        return true;
    }

}