<?php

namespace Dojo\SyracuseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SyracuseBundle extends Bundle
{
}
