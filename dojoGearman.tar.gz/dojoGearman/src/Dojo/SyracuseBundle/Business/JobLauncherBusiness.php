<?php

namespace Dojo\SyracuseBundle\Business;

use Mmoreram\GearmanBundle\Service\GearmanClient;

class JobLauncherBusiness
{
    const JOB_NAME = '@@TODO';

    /**
     * @var GearmanClient $gearman
     *
     */
    private $gearman;

    /**
     *
     * @var string
     */
    private $name;

    /**
     *
     * @param GearmanClient $gearman
     * @param string $name
     */
    public function __construct(GearmanClient $gearman, $name)
    {
        $this->gearman = $gearman;
        $this->name = $name;
    }

    /**
     * Launch a customer export job to gearman
     *
     * @param int $number
     * @return mixed
     */
    public function launch($number)
    {
        $params = array();

        $params['number'] = $number;
        $params['name'] = $this->name;

        $jobId = $this->gearman->callJob(
                self::JOB_NAME,
                json_encode($params)
            );
    }

    private function followJob($jobId)
    {
        $done = false;
        while (!$done) {
            $status = $this->gearman->getJobStatus($jobId);
            $done = !$status->isKnown();

            echo 'Job '
                . ($status->isRunning() ? '' : 'not ')
                . 'running.'
                . "\n"
                ;
            sleep(1);
        }
    }

}