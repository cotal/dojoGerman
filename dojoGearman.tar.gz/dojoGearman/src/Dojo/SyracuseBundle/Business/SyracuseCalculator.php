<?php

namespace Dojo\SyracuseBundle\Business;

use Symfony\Component\HttpKernel\Log\LoggerInterface;

class SyracuseCalculator
{

    /**
     *
     * @var int
     */
    protected $sleep;

    /**
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     *
     * @param LoggerInterface $logger
     * @param int $sleep
     */
    public function __construct(LoggerInterface $logger, $sleep)
    {
        $this->logger = $logger;
        $this->sleep = $sleep;
    }

    /**
     * Compute the Syracuse algorithm
     * @param int $number
     * @return int
     */
    public function compute($number)
    {
        $this->logger->info('Processing ' . $number);
        sleep($this->sleep);
        $number = intval($number);
        if ($number < 1) {
            throw new \InvalidArgumentException($number . ' is not a positif integer');
        }
        if ($number == 1) {
            return 1;
        }
        if ($number % 2 == 0) {
            return $this->compute($number/2);
        } else {
            return $this->compute($number*3 + 1);
        }
    }
}